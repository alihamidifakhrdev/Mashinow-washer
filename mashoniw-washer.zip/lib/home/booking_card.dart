import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/format.dart';
import '../core/jalali.dart';
import '../core/models.dart';
import '../core/theme.dart';
import '../core/ui.dart';
import 'scanner_page.dart';

/// کارت نوبت آنلاین (مشتری اپ/سایت)
class BookingCard extends StatelessWidget {
  final Booking booking;
  final VoidCallback? onTap;

  const BookingCard({super.key, required this.booking, this.onTap});

  @override
  Widget build(BuildContext context) {
    final DateTime? time = booking.displayTime;

    return AppCard(
      margin: const EdgeInsets.only(bottom: 14),
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: AppColors.accentTint(),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(Icons.directions_car_filled_rounded,
                    color: AppColors.accent, size: 24),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      booking.carModel.isEmpty
                          ? booking.carType
                          : '${booking.carType} ${booking.carModel}',
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontFamily: 'IRANYekan',
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: AppColors.ink,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      time != null
                          ? '${Jalali.fullDate(time)} • ساعت ${Jalali.clock(time)}'
                          : 'بدون زمان مشخص',
                      style: TextStyle(
                        fontFamily: 'IRANYekan',
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: AppColors.ink2,
                      ),
                    ),
                  ],
                ),
              ),
              StatusChip(status: booking.status),
            ],
          ),
          if (booking.services.isNotEmpty) ...<Widget>[
            const SizedBox(height: 14),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: <Widget>[
                for (final BookingService s in booking.services)
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: AppColors.fill,
                      borderRadius: BorderRadius.circular(99),
                    ),
                    child: Text(
                      s.name,
                      style: TextStyle(
                        fontFamily: 'IRANYekan',
                        fontSize: 11.5,
                        fontWeight: FontWeight.w600,
                        color: AppColors.ink2,
                      ),
                    ),
                  ),
              ],
            ),
          ],
          const SizedBox(height: 14),
          Row(
            children: <Widget>[
              Text(
                'کد پیگیری: ${booking.trackingCode}',
                style: TextStyle(
                  fontFamily: 'IRANYekan',
                  fontSize: 11.5,
                  fontWeight: FontWeight.w600,
                  color: AppColors.ink3,
                ),
              ),
              const Spacer(),
              Text(
                booking.sumPrices > 0 ? tomanLabel(booking.sumPrices) : '—',
                style: TextStyle(
                  fontFamily: 'IRANYekan',
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: AppColors.ink,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// کارت نوبت حضوری (مهمان)
class GuestBookingCard extends StatelessWidget {
  final GuestBooking booking;
  final VoidCallback? onTap;

  const GuestBookingCard({super.key, required this.booking, this.onTap});

  @override
  Widget build(BuildContext context) {
    final DateTime? time = booking.displayTime;

    return AppCard(
      margin: const EdgeInsets.only(bottom: 14),
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  // سبز — هویت «مشتری حضوری» (نوبت‌های آنلاین آبی‌اند)
                  color: AppColors.successTint(),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(Icons.person_rounded,
                    color: AppColors.success, size: 24),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      booking.customerName,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontFamily: 'IRANYekan',
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: AppColors.ink,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      time != null
                          ? '${Jalali.fullDate(time)} • ساعت ${Jalali.clock(time)}'
                          : 'بدون زمان مشخص',
                      style: TextStyle(
                        fontFamily: 'IRANYekan',
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: AppColors.ink2,
                      ),
                    ),
                  ],
                ),
              ),
              StatusChip(status: booking.status),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            'خودرو: ${booking.carModel}',
            style: TextStyle(
              fontFamily: 'IRANYekan',
              fontSize: 12.5,
              fontWeight: FontWeight.w600,
              color: AppColors.ink2,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: <Widget>[
              Text(
                'مشتری حضوری',
                style: TextStyle(
                  fontFamily: 'IRANYekan',
                  fontSize: 11.5,
                  fontWeight: FontWeight.w700,
                  color: AppColors.success,
                ),
              ),
              const Spacer(),
              Text(
                booking.services.isNotEmpty
                    ? tomanLabel(booking.services
                        .fold<int>(0, (int sum, BookingService s) => sum + s.price))
                    : '—',
                style: TextStyle(
                  fontFamily: 'IRANYekan',
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: AppColors.ink,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// دیتیل نوبت (آنلاین یا حضوری) — صفحات داخلی
class OrderDetailPage extends StatelessWidget {
  final Booking? booking;
  final GuestBooking? guest;

  const OrderDetailPage({super.key, this.booking, this.guest});

  String get _title => booking != null ? 'جزئیات نوبت' : 'جزئیات نوبت حضوری';

  @override
  Widget build(BuildContext context) {
    final List<BookingService> services =
        booking?.services ?? guest?.services ?? <BookingService>[];
    final DateTime? time = booking?.displayTime ?? guest?.displayTime;
    final String status = booking?.status ?? guest?.status ?? 'reserved';
    final String phone = guest?.customerPhone ?? '';
    final String name =
        guest?.customerName ?? booking?.carModel ?? '';

    final int total = services.fold<int>(
      0,
      (int sum, BookingService s) => sum + s.price,
    );

    return Scaffold(
      backgroundColor: AppColors.canvas,
      appBar: AppBar(
        title: Text(_title),
        // در RTL، actions سمت «چپِ» هدر می‌نشیند — دکمه اسکن کد رزرو مشتری
        actions: <Widget>[
          Padding(
            padding: const EdgeInsets.only(left: 14),
            child: Tooltip(
              message: 'اسکن کد رزرو',
              child: GestureDetector(
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (BuildContext c) => const ScannerPage(),
                    ),
                  );
                },
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: AppColors.blueTint(),
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: Icon(
                    Icons.qr_code_scanner_rounded,
                    color: AppColors.blue,
                    size: 22,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            AppCard(
              child: Column(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Text(
                          booking != null
                              ? '${booking!.carType} ${booking!.carModel}'
                              : name,
                          style: TextStyle(
                            fontFamily: 'IRANYekan',
                            fontSize: 17,
                            fontWeight: FontWeight.w900,
                            color: AppColors.ink,
                          ),
                        ),
                      ),
                      StatusChip(status: status),
                    ],
                  ),
                  if (guest != null) ...<Widget>[
                    const SizedBox(height: 14),
                    _InfoRow(icon: Icons.person_rounded, text: name),
                    const SizedBox(height: 8),
                    _InfoRow(
                      icon: Icons.phone_rounded,
                      text: phone,
                      ltr: true,
                      onTap: phone.length >= 10
                          ? () => _call(context, phone)
                          : null,
                    ),
                  ],
                  if (booking != null) ...<Widget>[
                    const SizedBox(height: 14),
                    _InfoRow(
                      icon: Icons.local_car_wash_rounded,
                      text: booking!.serviceType,
                    ),
                  ],
                  const SizedBox(height: 8),
                  _InfoRow(
                    icon: Icons.event_rounded,
                    text: time != null
                        ? '${Jalali.fullDate(time)} — ساعت ${Jalali.clock(time)}'
                        : 'بدون زمان مشخص',
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    'خدمات',
                    style: TextStyle(
                      fontFamily: 'IRANYekan',
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: AppColors.ink,
                    ),
                  ),
                  const SizedBox(height: 12),
                  if (services.isEmpty)
                    Text(
                      'خدمتی برای این نوبت ثبت نشده است',
                      style: TextStyle(
                        fontFamily: 'IRANYekan',
                        fontSize: 13,
                        color: AppColors.ink3,
                      ),
                    )
                  else
                    for (final BookingService s in services)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Text(
                              s.name,
                              style: TextStyle(
                                fontFamily: 'IRANYekan',
                                fontSize: 13.5,
                                fontWeight: FontWeight.w600,
                                color: AppColors.ink2,
                              ),
                            ),
                          ),
                          Text(
                            tomanLabel(s.price),
                            style: TextStyle(
                              fontFamily: 'IRANYekan',
                              fontSize: 13.5,
                              fontWeight: FontWeight.w700,
                              color: AppColors.ink,
                            ),
                          ),
                        ],
                      ),
                    ),
                  const Divider(height: 24),
                  Row(
                    children: <Widget>[
                      Text(
                        'مبلغ کل',
                        style: TextStyle(
                          fontFamily: 'IRANYekan',
                          fontSize: 14.5,
                          fontWeight: FontWeight.w800,
                          color: AppColors.ink,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        total > 0 ? tomanLabel(total) : '—',
                        style: TextStyle(
                          fontFamily: 'IRANYekan',
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          color: AppColors.accentDeep,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            if (booking != null)
              AppCard(
                child: Column(
                  children: <Widget>[
                    _InfoRow(
                      icon: Icons.account_balance_wallet_rounded,
                      text:
                          'پرداخت: ${paymentMethodLabel(booking!.paymentMethod)}',
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _call(BuildContext context, String phone) async {
    // شماره را به فرمت بین‌المللی می‌بریم
    final String tel = phone.startsWith('0')
        ? '+98${phone.substring(1)}'
        : phone;

    try {
      final Uri uri = Uri(scheme: 'tel', path: tel);

      if (await canLaunchUrl(uri)) {
        await launchUrl(uri);
      } else {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('امکان تماس با $tel نیست')),
          );
        }
      }
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('امکان تماس با $tel نیست')),
        );
      }
    }
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String text;
  final bool ltr;
  final VoidCallback? onTap;

  const _InfoRow({
    required this.icon,
    required this.text,
    this.ltr = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: onTap != null ? HitTestBehavior.opaque : HitTestBehavior.deferToChild,
      child: Row(
        children: <Widget>[
          Icon(icon, size: 19, color: AppColors.ink3),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              textDirection: ltr ? TextDirection.ltr : TextDirection.rtl,
              textAlign: ltr ? TextAlign.left : TextAlign.right,
              style: TextStyle(
                fontFamily: 'IRANYekan',
                fontSize: 13.5,
                fontWeight: FontWeight.w600,
                color: AppColors.ink2,
              ),
            ),
          ),
          if (onTap != null)
            Container(
              padding: const EdgeInsets.all(7),
              decoration: BoxDecoration(
                color: AppColors.accentTint(),
                borderRadius: BorderRadius.circular(99),
              ),
              child: Icon(Icons.phone_rounded,
                  color: AppColors.accent, size: 17),
            ),
        ],
      ),
    );
  }
}
