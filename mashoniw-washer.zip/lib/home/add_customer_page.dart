import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/format.dart';
import '../core/models.dart';
import '../core/theme.dart';
import '../core/ui.dart';
import 'dashboard_page.dart';

/// ثبت مشتری حضوری — carwash/carwash/guest-booking/create/
/// (همان فرم addCustomer سایت)
///
/// انتخاب ساعت با «نقشه‌ی ساعت روز» انجام می‌شود: یک فیلد تمیز که با
/// باتم‌شیت باز می‌شود؛ ساعت‌ها داخل شیت بر اساس صبح/ظهر/عصر/شب گروه
/// می‌شوند، ساعت‌های پر شده کم‌رنگ و خط‌خورده دیده می‌شوند تا تصویر
/// کامل روز جلوی چشم کارواش‌دار باشد.
class AddCustomerPage extends StatefulWidget {
  const AddCustomerPage({super.key});

  @override
  State<AddCustomerPage> createState() => _AddCustomerPageState();
}

class _AddCustomerPageState extends State<AddCustomerPage> {
  final TextEditingController _name = TextEditingController();
  final TextEditingController _phone = TextEditingController();
  final TextEditingController _carModel = TextEditingController();

  List<CarwashService> _services = <CarwashService>[];
  List<TimeSlot> _slots = <TimeSlot>[];

  final Set<int> _selectedServices = <int>{};
  TimeSlot? _selectedSlot;

  bool _loading = true;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _carModel.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final List<dynamic> results = await Future.wait(<Future<dynamic>>[
        Api.get('/carwash/carwash/services/'),
        Api.get('/carwash/time-slots/'),
      ]);

      if (!mounted) return;

      setState(() {
        _services = (results[0] as List? ?? <dynamic>[])
            .whereType<Map<String, dynamic>>()
            .map(CarwashService.fromJson)
            .toList();

        _slots = (results[1] as List? ?? <dynamic>[])
            .whereType<Map<String, dynamic>>()
            .map(TimeSlot.fromJson)
            .toList()
          ..sort((TimeSlot a, TimeSlot b) => a.start.compareTo(b.start));

        // اگر شیار انتخاب‌شده قبلی دیگر آزاد نبود، پاک شود
        if (_selectedSlot != null) {
          final bool stillFree = _slots.any((TimeSlot s) =>
              s.id == _selectedSlot!.id && !s.isReserved);
          if (!stillFree) _selectedSlot = null;
        }

        _loading = false;
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.message;
      });
    }
  }

  Future<void> _pickSlot() async {
    final TimeSlot? picked = await showModalBottomSheet<TimeSlot>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.45),
      builder: (BuildContext sheetContext) => _TimeSlotSheet(
        slots: _slots,
        initialSelected: _selectedSlot,
      ),
    );

    if (picked != null) {
      setState(() => _selectedSlot = picked);
    }
  }

  Future<void> _submit() async {
    final String phone = normalizeDigits(_phone.text).trim();

    if (_name.text.trim().isEmpty ||
        phone.length != 11 ||
        _carModel.text.trim().isEmpty) {
      showToast(
          context, 'نام، شماره تماس (۱۱ رقم) و مدل خودرو را کامل کنید',
          error: true);
      return;
    }

    if (_selectedSlot == null) {
      showToast(context, 'یک ساعت خالی را انتخاب کنید', error: true);
      return;
    }

    if (_selectedServices.isEmpty) {
      showToast(context, 'حداقل یک خدمت را انتخاب کنید', error: true);
      return;
    }

    setState(() => _saving = true);

    try {
      await Api.post(
        '/carwash/carwash/guest-booking/create/',
        data: <String, dynamic>{
          'customer_name': _name.text.trim(),
          'customer_phone': phone,
          'car_model': _carModel.text.trim(),
          'time_slot': _selectedSlot!.id,
          'service_ids': _selectedServices.toList(),
        },
      );

      if (!mounted) return;
      showToast(context, 'نوبت حضوری با موفقیت ثبت شد');

      // داشبورد بلافاصله نوبت جدید را در «آخرین نوبت‌ها» نشان بدهد
      DashboardRefresh.instance.bump();

      Navigator.of(context).pop();
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _saving = false);
      showToast(context, e.message, error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.canvas,
      appBar: AppBar(title: const Text('ثبت مشتری حضوری')),
      body: _loading
          ? Center(child: CircularProgressIndicator(color: AppColors.accent))
          : _error != null
              ? ListView(
                  children: <Widget>[
                    const SizedBox(height: 80),
                    EmptyState(
                      icon: Icons.wifi_off_rounded,
                      title: 'خطا در دریافت اطلاعات',
                      message: _error!,
                    ),
                  ],
                )
              : LayoutBuilder(
                  builder:
                      (BuildContext context, BoxConstraints constraints) {
                    return SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 24, vertical: 16),
                      child: ConstrainedBox(
                        constraints: BoxConstraints(
                            minHeight: constraints.maxHeight - 32),
                        child: Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: <Widget>[
                              AppTextField(
                                controller: _name,
                                label: 'نام مشتری',
                                hint: 'مثال: علی رضایی',
                              ),
                              const SizedBox(height: 16),
                              AppTextField(
                                controller: _phone,
                                label: 'شماره تماس',
                                hint: 'مثال: 09152685548',
                                keyboard: TextInputType.phone,
                                ltr: true,
                                maxLength: 11,
                                digitsOnly: true,
                              ),
                              const SizedBox(height: 16),
                              AppTextField(
                                controller: _carModel,
                                label: 'مدل خودرو',
                                hint: 'مثال: پژو ۲۰۶',
                              ),
                              const SizedBox(height: 24),

                              // :: انتخاب ساعت — فیلد بازکننده‌ی نقشه ساعت روز
                              _SlotField(
                                slot: _selectedSlot,
                                onTap: _pickSlot,
                              ),
                              const SizedBox(height: 24),

                              // :: انتخاب خدمات
                              Padding(
                                padding: const EdgeInsets.only(
                                    bottom: 12, right: 4),
                                child: Text(
                                  'خدمات',
                                  style: TextStyle(
                                    fontFamily: 'IRANYekan',
                                    fontSize: 13.5,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.ink2,
                                  ),
                                ),
                              ),
                              if (_services.isEmpty)
                                const AppCard(
                                  child: EmptyState(
                                    icon: Icons.list_alt_rounded,
                                    title: 'خدمتی ثبت نشده است',
                                    message:
                                        'اول از تب «تنظیمات» خدمات و تعرفه‌های کارواش را ثبت کنید.',
                                  ),
                                )
                              else
                                for (final CarwashService s in _services)
                                  _serviceRow(s),
                              const SizedBox(height: 90),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
      bottomNavigationBar: _loading || _error != null
          ? null
          : SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(24, 8, 24, 16),
                child: AppButton(
                  text: 'ثبت نوبت',
                  icon: Icons.check_rounded,
                  // سبز — ادامه‌ی هویت دکمه‌ی سبز «مشتری حضوری»
                  type: AppButtonType.success,
                  loading: _saving,
                  onPressed: _saving ? null : _submit,
                ),
              ),
            ),
    );
  }

  Widget _serviceRow(CarwashService s) {
    final bool selected = _selectedServices.contains(s.id);

    return AppCard(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      onTap: () => setState(() {
        if (selected) {
          _selectedServices.remove(s.id);
        } else {
          _selectedServices.add(s.id);
        }
      }),
      child: Row(
        children: <Widget>[
          Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              color: selected ? AppColors.accent : AppColors.fill2,
              borderRadius: BorderRadius.circular(8),
            ),
            child: selected
                ? const Icon(Icons.check_rounded,
                    color: Colors.white, size: 17)
                : null,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  s.serviceTypeName,
                  style: TextStyle(
                    fontFamily: 'IRANYekan',
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: AppColors.ink,
                  ),
                ),
                if (s.vehicleTypeName.isNotEmpty)
                  Text(
                    s.vehicleTypeName,
                    style: TextStyle(
                      fontFamily: 'IRANYekan',
                      fontSize: 11.5,
                      fontWeight: FontWeight.w500,
                      color: AppColors.ink3,
                    ),
                  ),
              ],
            ),
          ),
          Text(
            s.price > 0 ? tomanLabel(s.price) : '—',
            style: TextStyle(
              fontFamily: 'IRANYekan',
              fontSize: 13.5,
              fontWeight: FontWeight.w800,
              color: AppColors.accentDeep,
            ),
          ),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════
// انتخاب ساعت — نقشه‌ی ساعت روز
// ════════════════════════════════════════════════════════════════════

String _clockLabel(DateTime t) =>
    '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

class _DayPeriod {
  final String label;
  final IconData icon;

  const _DayPeriod(this.label, this.icon);
}

const List<_DayPeriod> _kPeriods = <_DayPeriod>[
  _DayPeriod('صبح', Icons.wb_twilight_rounded),
  _DayPeriod('ظهر', Icons.wb_sunny_rounded),
  _DayPeriod('عصر', Icons.wb_cloudy_rounded),
  _DayPeriod('شب', Icons.nightlight_rounded),
];

int _periodIndex(DateTime t) {
  final int h = t.hour;
  if (h < 12) return 0;
  if (h < 16) return 1;
  if (h < 20) return 2;
  return 3;
}

/// فیلد نمایش انتخاب ساعت داخل فرم
class _SlotField extends StatelessWidget {
  final TimeSlot? slot;
  final VoidCallback onTap;

  const _SlotField({required this.slot, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final TimeSlot? s = slot;
    final bool has = s != null;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppRadius.md),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: AppColors.fill,
            borderRadius: BorderRadius.circular(AppRadius.md),
          ),
          child: Row(
            children: <Widget>[
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: has ? AppColors.accentTint() : AppColors.blueTint(),
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Icon(
                  has ? Icons.event_available_rounded : Icons.schedule_rounded,
                  color: has ? AppColors.accent : AppColors.blue,
                  size: 22,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'انتخاب ساعت',
                      style: TextStyle(
                        fontFamily: 'IRANYekan',
                        fontSize: 11.5,
                        fontWeight: FontWeight.w600,
                        color: AppColors.ink3,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      has
                          ? '${_clockLabel(s.start)} تا ${_clockLabel(s.end)} — ${_kPeriods[_periodIndex(s.start)].label}'
                          : 'برای دیدن ساعت‌های آزاد بزنید',
                      style: TextStyle(
                        fontFamily: 'IRANYekan',
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: has ? AppColors.ink : AppColors.ink2,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Icon(Icons.expand_more_rounded,
                  size: 22, color: AppColors.ink3),
            ],
          ),
        ),
      ),
    );
  }
}

/// باتم‌شیت نقشه‌ی ساعت روز — گروه‌بندی صبح/ظهر/عصر/شب
class _TimeSlotSheet extends StatefulWidget {
  final List<TimeSlot> slots;
  final TimeSlot? initialSelected;

  const _TimeSlotSheet({
    required this.slots,
    required this.initialSelected,
  });

  @override
  State<_TimeSlotSheet> createState() => _TimeSlotSheetState();
}

class _TimeSlotSheetState extends State<_TimeSlotSheet> {
  TimeSlot? _selected;

  @override
  void initState() {
    super.initState();
    _selected = widget.initialSelected;
  }

  int get _freeCount =>
      widget.slots.where((TimeSlot s) => !s.isReserved).length;

  @override
  Widget build(BuildContext context) {
    final List<TimeSlot> sorted = widget.slots;

    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.80,
      ),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: const BorderRadius.vertical(
          top: Radius.circular(28),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          // :: دستگیره
          const SizedBox(height: 10),
          Center(
            child: Container(
              width: 42,
              height: 4.5,
              decoration: BoxDecoration(
                color: AppColors.fill2,
                borderRadius: BorderRadius.circular(99),
              ),
            ),
          ),

          // :: تیتر + وضعیت
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 16, 12),
            child: Row(
              children: <Widget>[
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: AppColors.blueTint(),
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: Icon(Icons.schedule_rounded,
                      color: AppColors.blue, size: 22),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'انتخاب ساعت نوبت',
                        style: TextStyle(
                          fontFamily: 'IRANYekan',
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          color: AppColors.ink,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '$_freeCount ساعت آزاد از ${sorted.length} بازه‌ی امروز',
                        style: TextStyle(
                          fontFamily: 'IRANYekan',
                          fontSize: 11.5,
                          fontWeight: FontWeight.w600,
                          color: AppColors.ink3,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: Icon(Icons.close_rounded,
                      size: 22, color: AppColors.ink3),
                ),
              ],
            ),
          ),

          // :: نقشه ساعت‌ها
          Flexible(
            child: sorted.isEmpty
                ? Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24, vertical: 36),
                    child: Text(
                      'بازه‌ی زمانی ثبت نشده است؛ از «تنظیمات ← زمان‌های کاری» بازه بسازید.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'IRANYekan',
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppColors.ink3,
                        height: 1.9,
                      ),
                    ),
                  )
                : ListView(
                    shrinkWrap: true,
                    padding: const EdgeInsets.fromLTRB(20, 2, 20, 12),
                    children: <Widget>[
                      for (int p = 0; p < _kPeriods.length; p++)
                        _buildPeriodSection(_kPeriods[p], p, sorted),
                    ],
                  ),
          ),

          // :: نوار تأیید
          Container(
            padding: EdgeInsets.fromLTRB(20, 12, 20,
                12 + MediaQuery.of(context).padding.bottom),
            decoration: BoxDecoration(
              color: AppColors.card,
              border: Border(
                top: BorderSide(color: AppColors.fill2, width: 1),
              ),
            ),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'ساعت انتخابی',
                        style: TextStyle(
                          fontFamily: 'IRANYekan',
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: AppColors.ink3,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        _selected != null
                            ? '${_clockLabel(_selected!.start)} تا ${_clockLabel(_selected!.end)}'
                            : 'هنوز انتخاب نشده',
                        style: TextStyle(
                          fontFamily: 'IRANYekan',
                          fontSize: 14.5,
                          fontWeight: FontWeight.w800,
                          color: _selected != null
                              ? AppColors.ink
                              : AppColors.ink3,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                ElevatedButton(
                  onPressed: _selected == null
                      ? null
                      : () => Navigator.of(context).pop(_selected),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.accent,
                    foregroundColor: Colors.white,
                    disabledBackgroundColor: AppColors.fill2,
                    disabledForegroundColor: AppColors.ink3,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 30, vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(AppRadius.md),
                    ),
                    textStyle: const TextStyle(
                      fontFamily: 'IRANYekan',
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  child: const Text('تایید'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPeriodSection(_DayPeriod period, int index, List<TimeSlot> all) {
    final List<TimeSlot> slots =
        all.where((TimeSlot s) => _periodIndex(s.start) == index).toList();

    if (slots.isEmpty) return const SizedBox.shrink();

    final int free =
        slots.where((TimeSlot s) => !s.isReserved).length;

    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          // :: سرگروه
          Row(
            children: <Widget>[
              Icon(period.icon, size: 17, color: AppColors.ink3),
              const SizedBox(width: 7),
              Text(
                period.label,
                style: TextStyle(
                  fontFamily: 'IRANYekan',
                  fontSize: 13.5,
                  fontWeight: FontWeight.w800,
                  color: AppColors.ink,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: free > 0
                      ? AppColors.accentTint(0.10)
                      : AppColors.fill2,
                  borderRadius: BorderRadius.circular(99),
                ),
                child: Text(
                  free > 0 ? '$free آزاد' : 'پر شده',
                  style: TextStyle(
                    fontFamily: 'IRANYekan',
                    fontSize: 10.5,
                    fontWeight: FontWeight.w800,
                    color: free > 0 ? AppColors.accentDeep : AppColors.ink3,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),

          // :: خانه‌های ساعت
          GridView.count(
            crossAxisCount: 4,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
            childAspectRatio: 1.65,
            children: <Widget>[
              for (final TimeSlot slot in slots)
                _SlotCell(
                  slot: slot,
                  selected: _selected?.id == slot.id,
                  onTap: slot.isReserved
                      ? null
                      : () => setState(() => _selected = slot),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

/// هر خانه‌ی ساعت — آزاد / انتخاب‌شده / رزروشده (خط‌خورده)
class _SlotCell extends StatelessWidget {
  final TimeSlot slot;
  final bool selected;
  final VoidCallback? onTap;

  const _SlotCell({
    required this.slot,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final bool free = !slot.isReserved;

    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOutCubic,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: selected
              ? AppColors.accent
              : free
                  ? AppColors.chipSurface
                  : AppColors.fill,
          borderRadius: BorderRadius.circular(12),
          border: free && !selected
              ? Border.all(color: AppColors.fill2)
              : null,
          boxShadow: selected
              ? <BoxShadow>[
                  BoxShadow(
                    color: AppColors.accent.withOpacity(0.32),
                    blurRadius: 12,
                    offset: const Offset(0, 5),
                    spreadRadius: -3,
                  ),
                ]
              : null,
        ),
        child: Text(
          _clockLabel(slot.start),
          style: TextStyle(
            fontFamily: 'IRANYekan',
            fontSize: 13.5,
            fontWeight: FontWeight.w800,
            color: selected
                ? Colors.white
                : free
                    ? AppColors.ink2
                    : AppColors.ink3,
            decoration: free ? null : TextDecoration.lineThrough,
            decorationColor: AppColors.ink3,
            decorationThickness: 1.8,
          ),
        ),
      ),
    );
  }
}
